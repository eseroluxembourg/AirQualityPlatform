import commands

for conta in range(1000):
    x = commands.getoutput("sudo python test_gps.py")