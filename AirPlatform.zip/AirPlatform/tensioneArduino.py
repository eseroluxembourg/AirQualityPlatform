import time
import serial
import urllib
import commands
import math


def floatERR(stringa):
     ritorno=None
     try:
      ritorno=float(stringa)
     except:
      ritorno=None
     return ritorno
    
    

f = open('/home/pi/AirPlatform/tensione.txt', 'r')
appo_stringa=f.read()
f.close()


print(appo_stringa)