import time
import serial
import datetime as dt

import commands



while 1:
   

    info = commands.getoutput('sudo python3 Client_ping.py')
    print(info)
     
    time.sleep(60)


