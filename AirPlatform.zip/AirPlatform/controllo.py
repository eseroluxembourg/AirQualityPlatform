import time
import serial
import datetime as dt

import commands

while 1:
   

    info = commands.getoutput('sudo python trova_driver.py')
    print(info)
     
    time.sleep(120)